
package com.example.timeslice;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;

public class PasswordRecoveryActivity extends AppCompatActivity {

    private EditText etEmail;
    private Button btnRecover;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_recovery);

        etEmail = findViewById(R.id.etEmail);
        btnRecover = findViewById(R.id.btnRecover);
        auth = FirebaseAuth.getInstance();

        btnRecover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                if (email.isEmpty()) {
                    Toast.makeText(PasswordRecoveryActivity.this, "Ingrese su correo", Toast.LENGTH_SHORT).show();
                    return;
                }
                enviarCorreoRecuperacion(email);
            }
        });
    }

    private void enviarCorreoRecuperacion(String email) {
        auth.sendPasswordResetEmail(email).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(PasswordRecoveryActivity.this, "Correo de recuperación enviado", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(PasswordRecoveryActivity.this, "Error: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
